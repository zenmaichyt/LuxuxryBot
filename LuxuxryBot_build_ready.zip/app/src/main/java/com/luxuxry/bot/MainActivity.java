
package com.luxuxry.bot;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.*;
import android.graphics.drawable.*;
import android.view.*;
import android.content.*;
import java.util.*;

public class MainActivity extends Activity {
    BotView view;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        view = new BotView(this);
        setContentView(view);
    }
    @Override public void onBackPressed() {
        if (!view.screen.equals("HOME")) { view.screen="MENU"; view.invalidate(); }
        else super.onBackPressed();
    }
}

class BotView extends View {
    Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    Bitmap bg;
    String screen="HOME";
    boolean bot=true, autoReply=true, incoming=true, typing=true, notify=true;
    int red=Color.rgb(255,32,40), green=Color.rgb(0,220,110);
    HashMap<String, Boolean> toggles = new HashMap<>();

    BotView(Context c) {
        super(c);
        bg=BitmapFactory.decodeResource(getResources(), getResources().getIdentifier(
                "luxuxry_background","drawable",c.getPackageName()));
        setFocusable(true);
    }

    void txt(Canvas c,String s,float x,float y,float size,int color,boolean bold){
        p.setColor(color); p.setTextSize(size); p.setTypeface(bold?Typeface.DEFAULT_BOLD:Typeface.DEFAULT);
        c.drawText(s,x,y,p);
    }
    void card(Canvas c,float l,float t,float r,float b){
        p.setColor(Color.argb(225,10,10,12)); p.setStyle(Paint.Style.FILL);
        c.drawRoundRect(l,t,r,b,24,24,p);
        p.setColor(Color.argb(120,255,32,40)); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2);
        c.drawRoundRect(l,t,r,b,24,24,p); p.setStyle(Paint.Style.FILL);
    }
    void line(Canvas c,float x1,float y,float x2){ p.setColor(Color.argb(80,255,255,255)); p.setStrokeWidth(1); c.drawLine(x1,y,x2,y,p); }
    void button(Canvas c,String s,float l,float t,float r,float b,boolean active){
        p.setColor(active?red:Color.rgb(30,30,34)); c.drawRoundRect(l,t,r,b,22,22,p);
        txt(c,s,l+18,t+32,16,Color.WHITE,true);
    }
    void toggle(Canvas c,float x,float y,boolean on){
        p.setColor(on?red:Color.rgb(55,55,60)); c.drawRoundRect(x,y,x+66,y+34,20,20,p);
        p.setColor(Color.WHITE); c.drawCircle(x+(on?49:17),y+17,12,p);
    }

    @Override protected void onDraw(Canvas c){
        super.onDraw(c);
        int w=getWidth(), h=getHeight();
        if(bg!=null){
            Rect src=new Rect(0,0,bg.getWidth(),bg.getHeight());
            Rect dst=new Rect(0,0,w,h);
            p.setAlpha(90); c.drawBitmap(bg,src,dst,p); p.setAlpha(255);
        }
        p.setColor(Color.argb(185,0,0,0)); c.drawRect(0,0,w,h,p);

        txt(c,"LUXUXRY BOT",24,46,22,Color.WHITE,true);
        txt(c,bot?"● BOT AKTIF":"● BOT NONAKTIF",w-180,44,14,bot?green:red,true);
        line(c,20,62,w-20);

        if(screen.equals("HOME")) home(c);
        else if(screen.equals("MENU")) menu(c);
        else if(screen.equals("AUTO")) auto(c);
        else if(screen.equals("KEYWORD")) keyword(c);
        else if(screen.equals("SCHEDULE")) schedule(c);
        else if(screen.equals("DELAY")) delay(c);
        else if(screen.equals("SAVED")) saved(c);
        else if(screen.equals("INCOMING")) incoming(c);
        else if(screen.equals("BLACKWHITE")) blackwhite(c);
        else if(screen.equals("STATS")) stats(c);
        else if(screen.equals("SETTINGS")) settings(c);
        else if(screen.equals("NOTIFY")) notify(c);
        bottom(c,w,h);
    }

    void title(Canvas c,String s){ txt(c,s,24,100,28,Color.WHITE,true); txt(c,"Luxuxry Bot",24,125,14,Color.LTGRAY,false); }

    void home(Canvas c){
        title(c,"HOME");
        card(c,20,150,getWidth()-20,250); txt(c,"Selamat datang di Luxuxry Bot",42,190,20,Color.WHITE,true);
        txt(c,"Bot WhatsApp otomatis siap digunakan.",42,220,15,Color.LTGRAY,false);
        button(c,"AKTIFKAN / NONAKTIFKAN BOT",40,280,getWidth()-40,335,bot);
        card(c,20,370,getWidth()-20,520);
        txt(c,"Ringkasan",42,405,19,red,true);
        txt(c,"Auto Reply",42,445,16,Color.WHITE,false); txt(c,autoReply?"AKTIF":"NONAKTIF",250,445,16,autoReply?green:red,true);
        txt(c,"Pesan Chat Masuk",42,480,16,Color.WHITE,false); txt(c,incoming?"AKTIF":"NONAKTIF",250,480,16,incoming?green:red,true);
    }

    void menu(Canvas c){
        title(c,"MENU FITUR");
        String[] names={"Auto Reply","Keyword Reply","Jadwal Aktif","Delay Balasan","Saved Replies","Pesan Chat Masuk","Blacklist & Whitelist","Statistik","Pengaturan Bot","Notifikasi"};
        String[] ids={"AUTO","KEYWORD","SCHEDULE","DELAY","SAVED","INCOMING","BLACKWHITE","STATS","SETTINGS","NOTIFY"};
        float y=155;
        for(int i=0;i<names.length;i++){
            card(c,20,y,getWidth()-20,y+58);
            txt(c,names[i],42,y+37,17,Color.WHITE,true);
            txt(c,"›",getWidth()-55,y+37,26,red,true);
            y+=68;
        }
    }

    void auto(Canvas c){
        title(c,"AUTO REPLY");
        card(c,20,155,getWidth()-20,245);
        txt(c,"Auto Reply",42,190,20,Color.WHITE,true); toggle(c,getWidth()-100,170,autoReply);
        txt(c,"Balas pesan masuk secara otomatis.",42,220,14,Color.LTGRAY,false);
        card(c,20,270,getWidth()-20,455);
        txt(c,"PESAN BALASAN",42,305,15,red,true);
        txt(c,"Halo {nama}! 👋",42,345,17,Color.WHITE,false);
        txt(c,"Terima kasih sudah menghubungi kami.",42,375,16,Color.WHITE,false);
        txt(c,"Ada yang bisa Luxuxry Bot bantu?",42,405,16,Color.WHITE,false);
        button(c,"SIMPAN",42,420,getWidth()-42,465,true);
    }

    void keyword(Canvas c){
        title(c,"KEYWORD REPLY");
        card(c,20,155,getWidth()-20,220); txt(c,"Kata Kunci",42,190,19,Color.WHITE,true);
        txt(c,"Tambah keyword dan balasan otomatis.",42,215,14,Color.LTGRAY,false);
        String[] k={"menu","harga","cara beli","pengiriman","pembayaran"};
        float y=245;
        for(String x:k){ card(c,20,y,getWidth()-20,y+58); txt(c,x,40,y+35,17,Color.WHITE,true); txt(c,"›",getWidth()-55,y+35,24,red,true); y+=68; }
        button(c,"+ TAMBAH KEYWORD",40,y+10,getWidth()-40,y+65,true);
    }

    void schedule(Canvas c){
        title(c,"JADWAL AKTIF");
        card(c,20,155,getWidth()-20,245); txt(c,"Gunakan Jadwal Aktif",42,190,19,Color.WHITE,true); toggle(c,getWidth()-100,170,true);
        txt(c,"Senin - Jumat     08:00 - 22:00",42,225,15,Color.LTGRAY,false);
        card(c,20,270,getWidth()-20,500);
        txt(c,"DAFTAR JADWAL",42,305,15,red,true);
        txt(c,"1  Senin - Jumat     08:00 - 22:00",42,350,16,Color.WHITE,false);
        txt(c,"2  Sabtu              09:00 - 21:00",42,405,16,Color.WHITE,false);
        txt(c,"3  Minggu             Nonaktif",42,460,16,Color.LTGRAY,false);
        button(c,"+ TAMBAH JADWAL BARU",40,530,getWidth()-40,585,true);
    }

    void delay(Canvas c){
        title(c,"DELAY BALASAN");
        card(c,20,155,getWidth()-20,300);
        txt(c,"Delay Acak (Random)",42,195,19,Color.WHITE,true);
        txt(c,"Minimum     2 detik",42,235,16,Color.LTGRAY,false);
        txt(c,"Maksimum    5 detik",42,270,16,Color.LTGRAY,false);
        card(c,20,325,getWidth()-20,455);
        txt(c,"Delay Tetap (Fixed)",42,365,19,Color.WHITE,true);
        txt(c,"3 detik",42,405,18,red,true);
        button(c,"SIMPAN DELAY",40,485,getWidth()-40,540,true);
    }

    void saved(Canvas c){
        title(c,"SAVED REPLIES");
        button(c,"+ TAMBAH PESAN BARU",30,155,250,210,true);
        String[] a={"Salam Pembuka","Info Produk","Pengiriman","Pembayaran","Promo","Penutup"};
        float y=235;
        for(String s:a){ card(c,20,y,getWidth()-20,y+62); txt(c,s,42,y+38,17,Color.WHITE,true); txt(c,"✎  🗑",getWidth()-100,y+38,16,red,false); y+=72; }
    }

    void incoming(Canvas c){
        title(c,"PESAN CHAT MASUK");
        card(c,20,155,getWidth()-20,245); txt(c,"Aktifkan fitur",42,190,19,Color.WHITE,true); toggle(c,getWidth()-100,170,incoming);
        card(c,20,270,getWidth()-20,470);
        txt(c,"PREVIEW CHAT",42,305,15,red,true);
        p.setColor(Color.rgb(35,45,48)); c.drawRoundRect(40,330,getWidth()-40,435,18,18,p);
        txt(c,"Halo kak 👋",60,365,16,Color.WHITE,false);
        txt(c,"Terima kasih sudah menghubungi kami.",60,395,14,Color.WHITE,false);
        txt(c,"Ada yang bisa Luxuxry Bot bantu?",60,420,14,Color.WHITE,false);
        card(c,20,500,getWidth()-20,640);
        txt(c,"Delay sebelum mengirim     2 detik",42,545,16,Color.WHITE,false);
        txt(c,"Kirim hanya sekali per pengguna",42,590,16,Color.WHITE,false);
    }

    void blackwhite(Canvas c){
        title(c,"BLACKLIST & WHITELIST");
        button(c,"BLACKLIST",25,155,getWidth()/2-10,210,true);
        button(c,"WHITELIST",getWidth()/2+10,155,getWidth()-25,210,false);
        card(c,20,235,getWidth()-20,530);
        txt(c,"DAFTAR KONTAK",42,270,15,red,true);
        String[] a={"+62 812-3456-7890","Rudi Pelanggan","+62 877-9988-7766","Doni"};
        float y=315;
        for(String s:a){ txt(c,s,45,y,16,Color.WHITE,false); line(c,40,y+18,getWidth()-40); y+=52; }
        button(c,"+ TAMBAH KONTAK",40,560,getWidth()-40,615,true);
    }

    void stats(Canvas c){
        title(c,"STATISTIK");
        card(c,20,155,getWidth()-20,245);
        txt(c,"Total Pesan",42,190,17,Color.WHITE,true); txt(c,"2.568",42,225,28,Color.WHITE,true);
        card(c,20,270,getWidth()-20,450);
        txt(c,"GRAFIK PESAN",42,305,15,red,true);
        p.setColor(red); p.setStrokeWidth(5);
        Path path=new Path(); path.moveTo(45,405); path.lineTo(120,370); path.lineTo(190,390); path.lineTo(260,340); path.lineTo(330,360); path.lineTo(400,320); c.drawPath(path,p);
        card(c,20,475,getWidth()-20,610);
        txt(c,"TOP KEYWORD",42,510,15,red,true);
        txt(c,"menu        468",42,550,16,Color.WHITE,false);
        txt(c,"harga       327",42,580,16,Color.WHITE,false);
    }

    void settings(Canvas c){
        title(c,"PENGATURAN BOT");
        card(c,20,155,getWidth()-20,250);
        txt(c,"Nama Bot",42,195,17,Color.WHITE,true); txt(c,"Luxuxry Bot",230,195,16,Color.LTGRAY,false);
        card(c,20,275,getWidth()-20,540);
        String[] a={"Status Bot","Mode 24/7","Respon di luar jam kerja","Tandai sudah dibaca","Tampilkan mengetik","Notifikasi suara"};
        float y=320;
        for(int i=0;i<a.length;i++){ txt(c,a[i],42,y,16,Color.WHITE,false); toggle(c,getWidth()-100,y-25,i!=3&&i!=5); y+=55; }
    }

    void notify(Canvas c){
        title(c,"NOTIFIKASI");
        card(c,20,155,getWidth()-20,245);
        txt(c,"Notifikasi Pesan",42,190,19,Color.WHITE,true); toggle(c,getWidth()-100,170,notify);
        card(c,20,270,getWidth()-20,570);
        String[] a={"Pesan Masuk Baru","Pesan Dibalas oleh Bot","Pengguna Baru","Kata Kunci Terdeteksi","Pesan Tidak Dikenali","Pesan Spam"};
        float y=315;
        for(int i=0;i<a.length;i++){ txt(c,a[i],42,y,16,Color.WHITE,false); toggle(c,getWidth()-100,y-25,i<4); y+=48; }
        card(c,20,595,getWidth()-20,710);
        txt(c,"WAKTU NOTIFIKASI",42,630,15,red,true);
        txt(c,"Selalu",42,670,16,Color.WHITE,false);
        txt(c,"08:00 - 22:00",180,670,16,Color.LTGRAY,false);
    }

    void bottom(Canvas c,int w,int h){
        int y=h-78;
        p.setColor(Color.argb(235,8,8,10)); c.drawRect(0,y,w,h,p);
        txt(c,"Home",45,y+48,13,Color.LTGRAY,false);
        txt(c,"Chat",145,y+48,13,Color.LTGRAY,false);
        txt(c,"Menu",w/2-18,y+48,13,red,true);
        txt(c,"Statistik",w-190,y+48,13,Color.LTGRAY,false);
        txt(c,"Pengaturan",w-100,y+48,13,Color.LTGRAY,false);
    }

    @Override public boolean onTouchEvent(android.view.MotionEvent e){
        if(e.getAction()!=MotionEvent.ACTION_UP) return true;
        float x=e.getX(), y=e.getY(); int h=getHeight(), w=getWidth();
        if(y>h-100){
            if(x<w*.2) screen="HOME";
            else if(x<w*.4) screen="INCOMING";
            else if(x<w*.6) screen="MENU";
            else if(x<w*.8) screen="STATS";
            else screen="SETTINGS";
            invalidate(); return true;
        }
        if(screen.equals("HOME") && y>270 && y<350){ bot=!bot; invalidate(); return true; }
        if(screen.equals("MENU")){
            String[] ids={"AUTO","KEYWORD","SCHEDULE","DELAY","SAVED","INCOMING","BLACKWHITE","STATS","SETTINGS","NOTIFY"};
            int idx=(int)((y-150)/68);
            if(idx>=0 && idx<ids.length){ screen=ids[idx]; invalidate(); return true; }
        }
        if(screen.equals("AUTO") && y>155 && y<245){ autoReply=!autoReply; invalidate(); }
        if(screen.equals("INCOMING") && y>155 && y<245){ incoming=!incoming; invalidate(); }
        if(screen.equals("NOTIFY") && y>155 && y<245){ notify=!notify; invalidate(); }
        return true;
    }
}
