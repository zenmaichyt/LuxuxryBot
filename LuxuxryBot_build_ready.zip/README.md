# Luxuxry Bot — starter project

Ini adalah project Android awal yang dibuat dari nol berdasarkan rancangan UI Luxuxry Bot.

## Fitur UI yang sudah disiapkan
- Home
- Menu Fitur
- Auto Reply
- Keyword Reply
- Jadwal Aktif
- Delay Balasan
- Saved Replies
- Pesan Chat Masuk + preview bergaya WhatsApp
- Blacklist & Whitelist
- Statistik
- Pengaturan Bot
- Notifikasi
- Tema gelap merah-hitam dan background visual

## Penting
Versi ini adalah **starter UI/prototype**. Mesin bot WhatsApp yang benar-benar mengirim dan membaca pesan belum diaktifkan. Integrasi WhatsApp perlu dibuat sebagai tahap berikutnya dan harus mengikuti izin/fitur Android yang tersedia.

## Membuka di HP
Project dapat dibuka dengan Android Studio atau AndroidIDE. Setelah Gradle selesai sync, jalankan app untuk membuat APK debug.

Nama aplikasi: Luxuxry Bot
Package: com.luxuxry.bot


## Build sekali klik via GitHub Actions

1. Upload project ini ke repository GitHub.
2. Buka tab **Actions**.
3. Pilih **Build Luxuxry Bot APK**.
4. Tekan **Run workflow**.
5. Setelah selesai, buka hasil workflow dan download artifact **LuxuxryBot-debug-apk**.
6. Di dalam ZIP artifact terdapat `app-debug.apk`.

Tidak perlu AndroidIDE. Workflow menggunakan JDK 17, Android SDK 35, dan Gradle 8.7 di server GitHub.
